import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DepartmentQuestionComponent } from './department-question/department-question.component';
import { DepartmentViewComponent } from './department-view/department-view.component';
import { QuizQuestionComponent } from './quiz-question/quiz-question.component';
import { ResultComponent } from './result/result.component';
import { StartComponent } from './start/start.component';


const routes: Routes = [
  { path: 'home', component: StartComponent },
  { path: 'quiz-result', component: ResultComponent },
  { path: 'quiz-questions', component: QuizQuestionComponent },
  { path: 'department-questions', component: DepartmentQuestionComponent },
  { path: 'department-result', component: DepartmentViewComponent },
  { path: '', redirectTo: 'home', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
