import { Router } from '@angular/router';
import { Department } from './../departemtn';
import { Component } from '@angular/core';

@Component({
  selector: 'app-department-view',
  templateUrl: './department-view.component.html',
  styleUrls: ['./department-view.component.scss']
})
export class DepartmentViewComponent {
  department: { name: string, score: number, img: string }[] = [
    { name: Department.Technology, score: 0, img: 'assets/images/technology.svg' },
    { name: Department.Strategy, score: 0, img: 'assets/images/strategy.svg' },
    { name: Department.Hr, score: 0, img: 'assets/images/hr.svg' },
    { name: Department.Financial, score: 0, img: 'assets/images/financial.svg' },
    { name: Department.Finance, score: 0, img: 'assets/images/finance.svg' },
    { name: Department.Affairs, score: 0, img: 'assets/images/affairs.svg' },
    { name: Department.Enterprise, score: 0, img: 'assets/images/enterprise.svg' },
    { name: Department.COPS, score: 0, img: 'assets/images/cops.svg' },
    { name: Department.Sales, score: 0, img: 'assets/images/sales.svg' },
    { name: Department.Business, score: 0, img: 'assets/images/business.svg' },
  ]
  departmentName = Department.Technology
  constructor(private router: Router) {

  }

  ngOnInit() {
    let departmentData = localStorage.getItem('scoreData') || ''
    let data: any[] = JSON.parse(departmentData)
    data.map(item => {
      let findIndex = this.department.findIndex(ele => ele.name.toLowerCase() == item?.Department.toLowerCase())
      if (findIndex >= 0)
        ++this.department[findIndex].score
    })
    this.department = this.department.sort((a, b) => b.score - a.score)
    this.department = this.department.filter(item => item.score !== 0);
    setTimeout(() => {
      this.router.navigateByUrl('/home')
      localStorage.removeItem("scoreData")
    }, 8000);
  }

}
