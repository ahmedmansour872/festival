import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DepartmentViewComponent } from './department-view.component';

describe('DepartmentViewComponent', () => {
  let component: DepartmentViewComponent;
  let fixture: ComponentFixture<DepartmentViewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DepartmentViewComponent]
    });
    fixture = TestBed.createComponent(DepartmentViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
