export enum Department {
  Technology = "Technology",
  Strategy = "Strategy",
  Hr = "HR & Property",
  Financial = "Financial Services",
  Finance = "Finance",
  Affairs = "External Affairs",
  Enterprise = "Enterprise",
  COPS = "COPS (Customer Care)",
  Sales = "Consumer Sales and Retail",
  Business = "CBU (Consumer Business Unit)",
}
