import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DepartmentQuestionComponent } from './department-question.component';

describe('DepartmentQuestionComponent', () => {
  let component: DepartmentQuestionComponent;
  let fixture: ComponentFixture<DepartmentQuestionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DepartmentQuestionComponent]
    });
    fixture = TestBed.createComponent(DepartmentQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
