import { Department } from './../departemtn';
import { Router } from '@angular/router';
import { Component } from '@angular/core';

@Component({
  selector: 'app-department-question',
  templateUrl: './department-question.component.html',
  styleUrls: ['./department-question.component.scss']
})
export class DepartmentQuestionComponent {
  questionView: any;

  technology: any[] = [
    {
      "id": 1,
      "question": "Do you enjoy solving complex technical problems?",
      "Department": "Technology"
    },
    {
      "id": 2,
      "question": "Are you always up-to-date with the latest tech trends?",
      "Department": "Technology"
    },
    {
      "id": 3,
      "question": "Do you enjoy coding in your free time?",
      "Department": "Technology"
    },
    {
      "id": 4,
      "question": "How important is innovation to you?",
      "Department": "Technology"
    },
    {
      "id": 5,
      "question": "Can you explain complex technical concepts simply?",
      "Department": "Technology"
    },
    {
      "id": 6,
      "question": "Are you comfortable with constant learning?",
      "Department": "Technology"
    },
    {
      "id": 7,
      "question": "Do you enjoy experimenting with new technologies?",
      "Department": "Technology"
    },
    {
      "id": 8,
      "question": "Can you prioritize multiple technical tasks?",
      "Department": "Technology"
    }
  ]

  strategy: any[] = [
    {
      "id": 1,
      "question": "Do you enjoy developing business strategies?",
      "Department": "Strategy"
    },
    {
      "id": 2,
      "question": "Are you comfortable working with data and analytics?",
      "Department": "Strategy"
    },
    {
      "id": 3,
      "question": "How important is innovation to you?",
      "Department": "Strategy"
    },
    {
      "id": 4,
      "question": "Can you develop business models and scenarios?",
      "Department": "Strategy"
    },
    {
      "id": 5,
      "question": "Do you prefer working in a fast-paced environment?",
      "Department": "Strategy"
    },
    {
      "id": 6,
      "question": "Are you comfortable working with stakeholders?",
      "Department": "Strategy"
    },
    {
      "id": 7,
      "question": "Do you enjoy identifying business opportunities and risks?",
      "Department": "Strategy"
    },
    {
      "id": 8,
      "question": "Can you develop business cases and proposals?",
      "Department": "Strategy"
    }
  ]

  hr: any[] = [
    {
      "id": 1,
      "question": "Do you enjoy building relationships with employees?",
      "Department": "HR & Property"
    },
    {
      "id": 2,
      "question": "Is diversity and inclusion important to you?",
      "Department": "HR & Property"
    },
    {
      "id": 3,
      "question": "Can you handle confidential employee matters?",
      "Department": "HR & Property"
    },
    {
      "id": 4,
      "question": "Do you prefer working in a supportive role?",
      "Department": "HR & Property"
    },
    {
      "id": 5,
      "question": "Are you comfortable with HR systems and tools?",
      "Department": "HR & Property"
    },
    {
      "id": 6,
      "question": "Do you enjoy creating employee engagement initiatives?",
      "Department": "HR & Property"
    },
    {
      "id": 7,
      "question": "Can you develop and implement corporate policies?",
      "Department": "HR & Property"
    },
    {
      "id": 8,
      "question": "Do you enjoy maintaining and developing properties?",
      "Department": "HR & Property"
    }
  ]

  financial: any[] = [
    {
      "id": 1,
      "question": "Do you enjoy developing financial solutions?",
      "Department": "Financial Services"
    },
    {
      "id": 2,
      "question": "Are you comfortable working with financial data and analytics?",
      "Department": "Financial Services"
    },
    {
      "id": 3,
      "question": "Is innovation important to you?",
      "Department": "Financial Services"
    },
    {
      "id": 4,
      "question": "Can you develop financial products and services?",
      "Department": "Financial Services"
    },
    {
      "id": 5,
      "question": "Do you prefer working in a fast-paced environment?",
      "Department": "Financial Services"
    },
    {
      "id": 6,
      "question": "Do you enjoy identifying financial opportunities and risks?",
      "Department": "Financial Services"
    },
    {
      "id": 7,
      "question": "Can you develop financial business cases?",
      "Department": "Financial Services"
    },
    {
      "id": 8,
      "question": "Do you have excellent problem-solving skills?",
      "Department": "Financial Services"
    }
  ]

  finance: any[] = [
    {
      "id": 1,
      "question": "Do you enjoy working with numbers?",
      "Department": "Finance"
    },
    {
      "id": 2,
      "question": "Are you comfortable with financial analysis and reporting?",
      "Department": "Finance"
    },
    {
      "id": 3,
      "question": "Is attention to detail important to you?",
      "Department": "Finance"
    },
    {
      "id": 4,
      "question": "Can you develop financial models and forecasts?",
      "Department": "Finance"
    },
    {
      "id": 5,
      "question": "Are you comfortable with financial software and systems?",
      "Department": "Finance"
    },
    {
      "id": 6,
      "question": "Do you enjoy identifying financial risks and opportunities?",
      "Department": "Finance"
    },
    {
      "id": 7,
      "question": "Can you develop financial policies and procedures?",
      "Department": "Finance"
    },
    {
      "id": 8,
      "question": "Do you have excellent analytical skills?",
      "Department": "Finance"
    }
  ]

  affairs: any[] = [
    {
      "id": 1,
      "question": "Do you enjoy public speaking?",
      "Department": "External Affairs"
    },
    {
      "id": 2,
      "question": "Are you comfortable working with media representatives?",
      "Department": "External Affairs"
    },
    {
      "id": 3,
      "question": "Is crisis management important to you?",
      "Department": "External Affairs"
    },
    {
      "id": 4,
      "question": "Can you develop communication strategies?",
      "Department": "External Affairs"
    },
    {
      "id": 5,
      "question": "Are you comfortable building relationships with external stakeholders?",
      "Department": "External Affairs"
    },
    {
      "id": 6,
      "question": "Do you enjoy writing press releases and media statements?",
      "Department": "External Affairs"
    },
    {
      "id": 7,
      "question": "Can you manage social media campaigns?",
      "Department": "External Affairs"
    },
    {
      "id": 8,
      "question": "Do you have excellent presentation skills?",
      "Department": "External Affairs"
    }
  ]

  enterprise: any[] = [
    {
      "id": 1,
      "question": "Do you enjoy developing business solutions?",
      "Department": "Enterprise"
    },
    {
      "id": 2,
      "question": "Are you comfortable working with large datasets?",
      "Department": "Enterprise"
    },
    {
      "id": 3,
      "question": "Can you communicate technical concepts to non-technical stakeholders?",
      "Department": "Enterprise"
    },
    {
      "id": 4,
      "question": "Do you prefer working on long-term projects?",
      "Department": "Enterprise"
    },
    {
      "id": 5,
      "question": "Do you enjoy identifying business opportunities?",
      "Department": "Enterprise"
    },
    {
      "id": 6,
      "question": "Can you develop and implement business plans?",
      "Department": "Enterprise"
    },
    {
      "id": 7,
      "question": "Do you have excellent project management skills?",
      "Department": "Enterprise"
    }
  ]

  cops: any[] = [
    {
      "id": 1,
      "question": "Do you enjoy helping others?",
      "Department": "COPS (Customer Care)"
    },
    {
      "id": 2,
      "question": "Are you patient with difficult customers?",
      "Department": "COPS (Customer Care)"
    },
    {
      "id": 3,
      "question": "How important is empathy to you?",
      "Department": "COPS (Customer Care)"
    },
    {
      "id": 4,
      "question": "Can you remain calm under pressure?",
      "Department": "COPS (Customer Care)"
    },
    {
      "id": 5,
      "question": "Do you prefer working in a fast-paced environment?",
      "Department": "COPS (Customer Care)"
    },
    {
      "id": 6,
      "question": "Are you comfortable with constant customer interaction?",
      "Department": "COPS (Customer Care)"
    },
    {
      "id": 7,
      "question": "Do you enjoy resolving conflicts?",
      "Department": "COPS (Customer Care)"
    },
    {
      "id": 8,
      "question": "Can you prioritize multiple customer requests?",
      "Department": "COPS (Customer Care)"
    }
  ]

  sales: any[] = [
    {
      "id": 1,
      "question": "Do you enjoy finding creative ways to showcase products?",
      "Department": "Consumer Sales and Retail"
    },
    {
      "id": 2,
      "question": "Are you comfortable handling customer complaints?",
      "Department": "Consumer Sales and Retail"
    },
    {
      "id": 3,
      "question": "Do you think outside the box when it comes to sales strategies?",
      "Department": "Consumer Sales and Retail"
    },
    {
      "id": 4,
      "question": "Are you motivated by meeting sales targets?",
      "Department": "Consumer Sales and Retail"
    },
    {
      "id": 5,
      "question": "Do you enjoy working in a fast-paced retail environment?",
      "Department": "Consumer Sales and Retail"
    },
    {
      "id": 6,
      "question": "Are you comfortable working with point-of-sale systems?",
      "Department": "Consumer Sales and Retail"
    },
    {
      "id": 7,
      "question": "Do you think customer loyalty is crucial to sales success?",
      "Department": "Consumer Sales and Retail"
    },
    {
      "id": 8,
      "question": "Are you willing to go the extra mile to ensure customer satisfaction?",
      "Department": "Consumer Sales and Retail"
    }
  ]

  business: any[] = [
    {
      "id": 1,
      "question": "Do you enjoy analyzing customer behavior and preferences?",
      "Department": "CBU (Consumer Business Unit)"
    },
    {
      "id": 2,
      "question": "Are you comfortable developing marketing campaigns across multiple channels?",
      "Department": "CBU (Consumer Business Unit)"
    },
    {
      "id": 3,
      "question": "How important is understanding competitor activity to you?",
      "Department": "CBU (Consumer Business Unit)"
    },
    {
      "id": 4,
      "question": "Can you develop and execute go-to-market strategies?",
      "Department": "CBU (Consumer Business Unit)"
    },
    {
      "id": 5,
      "question": "Do you prefer working on innovative and creative marketing projects?",
      "Department": "CBU (Consumer Business Unit)"
    },
    {
      "id": 6,
      "question": "How do you stay up-to-date with the latest marketing trends and technologies?",
      "Department": "CBU (Consumer Business Unit)"
    },
    {
      "id": 7,
      "question": "Are you comfortable working with data and analytics to measure marketing performance?",
      "Department": "CBU (Consumer Business Unit)"
    },
    {
      "id": 8,
      "question": "Do you enjoy developing brand positioning and messaging?",
      "Department": "CBU (Consumer Business Unit)"
    }
  ]

  allData: any[][] = [
    this.technology,
    this.strategy,
    this.hr,
    this.financial,
    this.finance,
    this.affairs,
    this.enterprise,
    this.cops,
    this.sales,
    this.business
  ]

  data: any[] = []
  answers: string[] = ['Yes', 'No', 'Mostly']
  score: any[] = []
  constructor(private router: Router) { }

  ngOnInit() {
    for (let i = 0; i < this.allData?.length; i++) {
      for (let index = 0; index < 2; index++) {
        let question = this.calcRandomNumber(this.allData[i]);
        this.data.push(question)
      }
    }
    this.calcRandomNumberandGenerateQuestion()
  }

  showAnswer(item: string) {
    if (item.toLowerCase() == 'yes')
      this.score.push(this.questionView)
    if (this.data.length == 0) {
      let scoreData = JSON.stringify(this.score)
      localStorage.setItem('scoreData', scoreData)
      console.log("finish =======>>>>>>>")
      this.router.navigateByUrl('/department-result')
    }
    this.calcRandomNumberandGenerateQuestion()
    // let clear = setTimeout(() => {
    // this.calcRandomNumberandGenerateQuestion()
    //   clearTimeout(clear)
    // }, 1000);
  }

  calcRandomNumber(arrayName: any = []) {
    const randomNumber = Math.floor(Math.random() * arrayName.length);
    let question = arrayName[randomNumber];
    arrayName.splice(randomNumber, 1);
    return question
  }

  calcRandomNumberandGenerateQuestion() {
    const randomNumber = Math.floor(Math.random() * this.data.length);
    this.questionView = this.data[randomNumber];
    this.data.splice(randomNumber, 1);
  }
}
